# VOICE BRIDGE Backend

Flask API for YouTube analysis jobs, versioned audio-description manifests,
and immutable WAV clip delivery.

## Local setup

Do not copy or commit `.venv` from another computer. Recreate it locally.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
.\.venv\Scripts\python.exe -m pip install pytest
Copy-Item .env.example .env
```

Set `OPENAI_API_KEY` in `.env`, then start the local API:

```powershell
.\.venv\Scripts\python.exe app.py
```

The Chrome extension expects `http://localhost:8000`.

## Public API used by the extension

- `GET /v1/health`
- `POST /v1/jobs`
- `GET /v1/jobs/{job_id}`
- `GET /v1/manifests/{provider}/{video_id}`
- `GET /v1/audio/{sha256}.wav`

`POST /v1/jobs` accepts only a validated provider, video ID, and duration. The
server downloads the corresponding YouTube media and runs M1-M5 in a background
worker. The extension never uploads page frames or audio.

## Generated data

SQLite is the runtime source of truth. `data/manifests`, `data/audio`,
`data/jobs`, and `runs` are generated artifacts and are ignored by Git. The
`runs` directory may contain extracted audio and video frames, so do not expose
it through the web server or include it in a public archive.

The local POC uses one background worker. Do not run multiple WSGI worker
processes without adding a database-backed job claim, or the same paid analysis
job may execute more than once.
