import {
  isExtensionMessage,
  type AccessibilityAnnounce,
  type ManifestGet,
  type PlayerContext,
} from '../shared/contracts/messages';
import { parseManifestV1_1 } from '../shared/contracts/manifest';
import {
  parseStoredPlaybackSettings,
  PLAYBACK_SETTINGS_STORAGE_KEY,
  type PlaybackSettings,
} from '../shared/settings/playback-settings';
import { YouTubePlayerController } from './player-controller';
import { PlaybackCoordinator } from './playback/playback-coordinator';
import { RuntimeAudioGateway } from './playback/runtime-audio-gateway';
import { SchedulerRuntime } from './scheduler/scheduler-runtime';
import {
  ACCESSIBILITY_SETTINGS_STORAGE_KEY,
  parseStoredAccessibilitySettings,
} from '../shared/settings/accessibility-settings';
import { FeedbackSoundPlayer } from '../shared/accessibility/feedback-sound';

const CONTENT_MARKER = 'data-voice-bridge-content';
const LIVE_REGION_MARKER = 'data-voice-bridge-live-region';
const MANIFEST_RETRY_MS = 3000;
const pageFeedbackSoundPlayer = new FeedbackSoundPlayer();
const pageAccessibilitySettingsReady = chrome.storage.local
  .get(ACCESSIBILITY_SETTINGS_STORAGE_KEY)
  .then((stored) => {
    const settings = parseStoredAccessibilitySettings(
      stored[ACCESSIBILITY_SETTINGS_STORAGE_KEY],
    );
    pageFeedbackSoundPlayer.setEnabled(settings.interaction_sounds_enabled);
    pageFeedbackSoundPlayer.setVolume(settings.interaction_sound_volume);
  })
  .catch(() => undefined);

function createLiveRegion(urgency: AccessibilityAnnounce['urgency']): HTMLElement {
  const element = document.createElement('p');
  element.setAttribute(LIVE_REGION_MARKER, urgency);
  element.setAttribute('role', urgency === 'assertive' ? 'alert' : 'status');
  element.setAttribute('aria-live', urgency);
  element.setAttribute('aria-atomic', 'true');
  Object.assign(element.style, {
    position: 'fixed',
    width: '1px',
    height: '1px',
    padding: '0',
    margin: '-1px',
    overflow: 'hidden',
    clip: 'rect(0, 0, 0, 0)',
    whiteSpace: 'nowrap',
    border: '0',
  });
  document.body.append(element);
  return element;
}

function announceOnPage(message: AccessibilityAnnounce): void {
  if (!message.speech_handled) {
    const selector = `[${LIVE_REGION_MARKER}="${message.urgency}"]`;
    const element =
      document.querySelector<HTMLElement>(selector) ?? createLiveRegion(message.urgency);
    element.textContent = '';
    window.setTimeout(() => {
      element.textContent = message.text;
    }, 40);
  }
  void pageAccessibilitySettingsReady
    .then(() => pageFeedbackSoundPlayer.unlock())
    .then(() => pageFeedbackSoundPlayer.play(message.tone))
    .catch(() => undefined);
}

if (!document.documentElement.hasAttribute(CONTENT_MARKER)) {
  document.documentElement.setAttribute(CONTENT_MARKER, 'ready');

  let controller: YouTubePlayerController;
  let schedulerRuntime: SchedulerRuntime;
  const manifestRequests = new Set<string>();
  const manifestRetryAfter = new Map<string, number>();

  function requestManifest(context: PlayerContext): void {
    if (!context.available || schedulerRuntime.hasManifest(context.video_key)) {
      return;
    }
    const now = Date.now();
    if (
      manifestRequests.has(context.video_key) ||
      now < (manifestRetryAfter.get(context.video_key) ?? 0)
    ) {
      return;
    }

    const requestedVideoKey = context.video_key;
    manifestRequests.add(requestedVideoKey);
    const request: ManifestGet = {
      type: 'MANIFEST_GET',
      provider: context.provider,
      video_id: context.video_id,
      duration_ms: context.duration_ms,
    };
    void chrome.runtime
      .sendMessage(request)
      .then((response: unknown) => {
        if (
          typeof response === 'object' &&
          response !== null &&
          (response as Record<string, unknown>).ok === true
        ) {
          const manifest = parseManifestV1_1(
            (response as { manifest: unknown }).manifest,
          );
          const manifestVideoKey =
            `${manifest.video.provider}:${manifest.video.video_id}`;
          if (manifestVideoKey !== requestedVideoKey) {
            throw new Error('Manifest video key changed while loading');
          }
          schedulerRuntime.setManifest(manifest);
          manifestRetryAfter.delete(requestedVideoKey);
          return;
        }

        const retryAfter =
          typeof response === 'object' &&
          response !== null &&
          Number.isInteger((response as Record<string, unknown>).retry_after_ms)
            ? Number((response as Record<string, unknown>).retry_after_ms)
            : MANIFEST_RETRY_MS;
        manifestRetryAfter.set(
          requestedVideoKey,
          Date.now() + Math.max(MANIFEST_RETRY_MS, retryAfter),
        );
      })
      .catch((error: unknown) => {
        console.warn('[VOICE BRIDGE] Manifest load failed.', error);
        manifestRetryAfter.set(requestedVideoKey, Date.now() + MANIFEST_RETRY_MS);
      })
      .finally(() => {
        manifestRequests.delete(requestedVideoKey);
      });
  }

  controller = new YouTubePlayerController((context, reason) => {
    schedulerRuntime.handlePlayerContext(context, reason);
    requestManifest(context);
  });
  const playbackCoordinator = new PlaybackCoordinator(
    controller,
    new RuntimeAudioGateway(),
  );
  schedulerRuntime = new SchedulerRuntime(
    () => controller.getContext(),
    playbackCoordinator,
  );

  function applyAndPersistSettings(settings: PlaybackSettings): void {
    schedulerRuntime.updateSettings(settings);
    void chrome.storage.local
      .set({ [PLAYBACK_SETTINGS_STORAGE_KEY]: settings })
      .catch((error: unknown) => {
        console.error('[VOICE BRIDGE] Failed to save playback settings.', error);
      });
  }

  chrome.runtime.onMessage.addListener((message: unknown, _sender, sendResponse) => {
    if (!isExtensionMessage(message)) {
      return false;
    }
    if (message.type === 'PLAYER_CONTEXT_GET') {
      sendResponse(controller.getContext());
      return false;
    }
    if (message.type === 'SCHEDULER_STATUS_GET') {
      sendResponse(schedulerRuntime.getStatus());
      return false;
    }
    if (message.type === 'DESCRIPTION_ENABLED_SET') {
      applyAndPersistSettings({
        ...schedulerRuntime.getStatus().settings,
        enabled: message.enabled,
      });
      sendResponse(schedulerRuntime.getStatus());
      return false;
    }
    if (message.type === 'PLAYBACK_SETTINGS_SET') {
      applyAndPersistSettings(message.settings);
      sendResponse(schedulerRuntime.getStatus());
      return false;
    }
    if (message.type === 'ACCESSIBILITY_ANNOUNCE') {
      announceOnPage(message);
      sendResponse({ ok: true });
      return false;
    }
    return false;
  });

  window.addEventListener('beforeunload', () => {
    chrome.storage.onChanged.removeListener(handleStorageChange);
    controller.stop();
    schedulerRuntime.stop();
  });

  const handleStorageChange = (
    changes: Record<string, chrome.storage.StorageChange>,
    areaName: string,
  ): void => {
    if (areaName !== 'local') {
      return;
    }
    if (changes[PLAYBACK_SETTINGS_STORAGE_KEY]) {
      schedulerRuntime.updateSettings(
        parseStoredPlaybackSettings(changes[PLAYBACK_SETTINGS_STORAGE_KEY].newValue),
      );
    }
    if (changes[ACCESSIBILITY_SETTINGS_STORAGE_KEY]) {
      const settings = parseStoredAccessibilitySettings(
        changes[ACCESSIBILITY_SETTINGS_STORAGE_KEY].newValue,
      );
      pageFeedbackSoundPlayer.setEnabled(settings.interaction_sounds_enabled);
      pageFeedbackSoundPlayer.setVolume(settings.interaction_sound_volume);
    }
  };
  chrome.storage.onChanged.addListener(handleStorageChange);

  void chrome.storage.local
    .get(PLAYBACK_SETTINGS_STORAGE_KEY)
    .then((stored) => {
      schedulerRuntime.updateSettings(
        parseStoredPlaybackSettings(stored[PLAYBACK_SETTINGS_STORAGE_KEY]),
      );
    })
    .catch((error: unknown) => {
      console.error('[VOICE BRIDGE] Failed to load playback settings.', error);
    })
    .finally(() => {
      controller.start();
      schedulerRuntime.start();
      console.info('[VOICE BRIDGE] YouTube player adapter and scheduler ready.');
    });
}
