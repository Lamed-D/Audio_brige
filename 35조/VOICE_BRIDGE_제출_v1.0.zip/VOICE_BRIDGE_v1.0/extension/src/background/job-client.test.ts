import assert from 'node:assert/strict';

import validManifestFixture from '../../fixtures/manifest-v1.1.valid.json';
import { JobClient } from './job-client';

const TARGET = {
  provider: 'youtube' as const,
  video_id: 'dQw4w9WgXcQ',
  duration_ms: 213061,
};

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

export async function runJobClientTests(): Promise<void> {
  const originalFetch = globalThis.fetch;
  const client = new JobClient('http://localhost:8000');

  try {
    globalThis.fetch = async () => jsonResponse(validManifestFixture);
    const ready = await client.getManifest(TARGET);
    assert.equal(ready.ok, true);
    if (ready.ok) {
      assert.equal(ready.manifest.manifest_id, 'youtube:dQw4w9WgXcQ:r1');
    }

    globalThis.fetch = async () =>
      jsonResponse(
        {
          job_id: 'a85d61164cf74506bc180d3550d6ff67',
          status: 'processing',
          video_key: 'youtube:dQw4w9WgXcQ',
          stage: 'visual_analysis',
          progress_percent: 50,
          eta_seconds: 20,
          eta_confidence: 'medium',
          retry_after_ms: 2500,
          updated_at: '2026-08-19T00:00:00.000Z',
        },
        202,
      );
    const processing = await client.getManifest(TARGET);
    assert.deepEqual(processing, {
      ok: false,
      reason: 'not_ready',
      retry_after_ms: 2500,
    });

    globalThis.fetch = async () => jsonResponse({ error: {} }, 404);
    const missing = await client.getManifest(TARGET);
    assert.equal(missing.ok, false);
    if (!missing.ok) {
      assert.equal(missing.reason, 'not_found');
    }

    globalThis.fetch = async () =>
      jsonResponse({
        ...validManifestFixture,
        video: { ...validManifestFixture.video, video_id: '3REAPXOdi-Y' },
        manifest_id: 'youtube:3REAPXOdi-Y:r1',
      });
    const mismatch = await client.getManifest(TARGET);
    assert.equal(mismatch.ok, false);
    if (!mismatch.ok) {
      assert.equal(mismatch.reason, 'invalid_response');
    }
  } finally {
    globalThis.fetch = originalFetch;
  }

  console.log('backend manifest client tests passed');
}
