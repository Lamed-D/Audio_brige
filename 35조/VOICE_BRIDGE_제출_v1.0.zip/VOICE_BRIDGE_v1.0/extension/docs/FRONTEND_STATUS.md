# VOICE BRIDGE 프론트엔드 인수인계

## 현재 기준

- 패키지 버전: `0.3.0`
- Chrome 최소 버전: `116`
- 지원 플랫폼: YouTube
- 백엔드 기본 주소: `http://localhost:8000`
- manifest 계약: `1.1`
- 작업 상태 계약: `1.2`

## 구현 완료

- YouTube 영상 식별, SPA 이동과 플레이어 교체 감지
- 화면해설 Scheduler, overlay 더킹, extended 자동 정지와 안전 복구
- Offscreen Document 기반 백엔드 WAV 재생
- 작업 생성, 진행률·ETA 조회, 상태 복원, 배지와 완료 알림
- `MANIFEST_GET`을 통한 Service Worker의 백엔드 manifest 조회
- Content Scheduler 동적 manifest 적재와 영상 키·길이 재검증
- 준비 중 manifest 재시도와 동일 영상 중복 요청 억제
- 영상이 바뀐 뒤 도착한 이전 manifest 응답 폐기
- 데모 manifest와 번들 WAV 제거
- Side Panel 설정, 키보드 단축키, 자체 TTS와 NVDA용 ARIA 안내
- 조작 알림음, 200% 확대와 Windows 고대비 모드 대응

## 실제 연동 흐름

1. Content Script가 현재 YouTube `video_id`와 재생 길이를 읽습니다.
2. Service Worker가 `GET /v1/manifests/youtube/{video_id}`를 호출합니다.
3. `404`이면 미생성 상태, `202`이면 준비 중 상태로 일정 시간 뒤 재시도합니다.
4. `200`이면 Manifest 1.1을 런타임 검증한 뒤 Content Script로 반환합니다.
5. Scheduler가 현재 영상과 일치하는 manifest만 적재합니다.
6. 재생 시 Service Worker가 `/v1/audio/{sha256}.wav`를 절대 URL로 변환합니다.
7. Offscreen Document가 WAV를 재생하고 Content Script가 더킹·정지·복구를 담당합니다.

## 검증 완료

- FE 타입 검사와 전체 단위 테스트
- manifest 성공·준비 중·미등록·영상 불일치 클라이언트 테스트
- BE 테스트 34개
- 실제 게시 manifest `youtube:3REAPXOdi-Y:r1`의 FE 파싱
- 9개 세그먼트 조회와 첫 WAV SHA-256 일치 확인

## 남은 수동 검증

- Chrome에서 확장프로그램을 다시 로드한 뒤 대상 YouTube 영상 재생
- 첫 세그먼트 시점의 실제 더킹과 TTS 청취
- 탐색·일시정지·영상 전환 중 해설 취소와 원본 상태 복구
- NVDA를 켠 상태에서 생성 완료와 오류 안내 확인

## 설정 변경 위치

- API 주소: `src/shared/config/constants.ts`
- Chrome API 접근 권한: `extension/manifest.json`
- 색상 토큰: `extension/styles/tokens.css`
- manifest 계약: `contracts/manifest-v1.1.schema.json`
- 작업 상태 계약: `contracts/job-status-v1.2.schema.json`
- NVDA 수동 검증: `docs/NVDA_테스트_체크리스트.md`
