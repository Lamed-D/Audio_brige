const path = require('path');
const TerserPlugin = require('terser-webpack-plugin');

module.exports = (_env, argv = {}) => {
  const isProduction = argv.mode === 'production';

  return {
    entry: {
      background: './src/background/index.ts',
      content: './src/content/index.ts',
      offscreen: './src/offscreen/index.ts',
      sidepanel: './src/sidepanel/index.ts',
    },
    output: {
      path: path.resolve(__dirname, 'extension'),
      filename: '[name].js',
      clean: false,
    },
    devtool: isProduction ? false : 'source-map',
    resolve: {
      extensions: ['.ts', '.js'],
    },
    module: {
      rules: [
        {
          test: /\.ts$/,
          use: 'ts-loader',
          exclude: /node_modules/,
        },
      ],
    },
    optimization: {
      minimize: isProduction,
      minimizer: [
        new TerserPlugin({
          terserOptions: {
            output: { ascii_only: true },
          },
        }),
      ],
    },
  };
};
