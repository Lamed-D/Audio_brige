import { rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const outputNames = ['background', 'content', 'offscreen', 'sidepanel'];
const obsoleteRuntimeFiles = [
  'icons/icon.svg',
  'icons/icon-t.png',
  'icons/logo-popup.png',
  'demo-audio/seg-001.wav',
  'demo-audio/seg-002.wav',
];

await Promise.all(
  [
    ...outputNames.flatMap((name) => [
      `${name}.js`,
      `${name}.js.map`,
    ]),
    ...obsoleteRuntimeFiles,
  ].map((relativePath) =>
    rm(resolve('extension', relativePath), { force: true }),
  ),
);
